from unittest.mock import MagicMock
import pydantic_ai
from app.core.config import Settings
from app.schemas.v4.rag import GateResult
from app.services.v4.rag_gate import RagGate
from app.services.v4.burr_orchestrator import BurrOrchestrator


def test_v4_rag_gate_classify(monkeypatch):
    mock_run_result = MagicMock()
    mock_run_result.output = GateResult(
        route="rag",
        reason="Needs project data.",
        requested_tool="generate_pdf",
        reply=None,
    )

    # Mock pydantic_ai.Agent.run_sync
    monkeypatch.setattr(pydantic_ai.Agent, "run_sync", lambda self, prompt: mock_run_result)

    settings = Settings()
    settings.local_llm_base_url = "http://mock"
    settings.local_llm_gate_model = "fake-model"
    settings.local_llm_gate_url = "http://mock"

    gate = RagGate(settings)
    res = gate.classify("Hello")

    assert res.route == "rag"
    assert res.reason == "Needs project data."
    assert res.requested_tool == "generate_pdf"
    assert res.reply is None


def test_burr_orchestrator_build():
    # Mock dependencies
    rewriter = MagicMock()
    gate = MagicMock()
    generic_agent = MagicMock()
    rrf_retriever = MagicMock()
    rag_synthesis = MagicMock()
    decision_agent = MagicMock()
    conversation_memory = MagicMock()
    settings = MagicMock()
    settings.v2_confidence_threshold = 0.7

    orchestrator = BurrOrchestrator(
        rewriter=rewriter,
        gate=gate,
        generic_agent=generic_agent,
        rrf_retriever=rrf_retriever,
        rag_synthesis=rag_synthesis,
        decision_agent=decision_agent,
        conversation_memory=conversation_memory,
        settings=settings,
    )

    initial_state = {
        "query": "test query",
        "conversation_context": "",
        "client_requested_tool": None,
        "has_corpus": True,
        "use_cloud_llm": False,
        "route": None,
        "gate_result": None,
        "rewritten_query": "test query",
        "sources": [],
        "answer": "",
        "verdict": "good",
        "confidence": 1.0,
        "attempt": 1,
        "max_attempts": 2,
        "prev_feedback": None,
        "project_ctx": None,
        "project_id": None,
        "conversation_id": None,
        "modality_filter": None,
    }

    app = orchestrator.build_application(initial_state)
    assert app is not None
    # Verify the starting state and entrypoint
    assert app.get_next_action().name == "precheck"


def test_run_budget_controller_validation():
    import pytest
    from app.services.v4.run_budget import RunBudget, BudgetExceededError

    # Safe state, well within the (deliberately generous) production defaults.
    budget = RunBudget(
        attempts=1,
        llm_calls=5,
        web_searches=1,
        tools=2,
        input_tokens=15000,
    )
    budget.check()  # should not raise

    # These assert check()'s enforcement logic against explicit low ceilings,
    # independent of whatever the production defaults are set to (which are
    # intentionally high — see run_budget.py / config.py run_budget_*).

    # Too many attempts
    with pytest.raises(BudgetExceededError) as exc_info:
        RunBudget(max_attempts=2, attempts=3).check()
    assert "Attempts count" in str(exc_info.value)

    # Too many LLM calls
    with pytest.raises(BudgetExceededError) as exc_info:
        RunBudget(max_llm_calls=6, llm_calls=7).check()
    assert "LLM calls count" in str(exc_info.value)

    # Too many web searches
    with pytest.raises(BudgetExceededError) as exc_info:
        RunBudget(max_web_searches=2, web_searches=3).check()
    assert "Web search count" in str(exc_info.value)

    # Too many tools
    with pytest.raises(BudgetExceededError) as exc_info:
        RunBudget(max_tools=3, tools=4).check()
    assert "Tool execution count" in str(exc_info.value)

    # Too many input tokens
    with pytest.raises(BudgetExceededError) as exc_info:
        RunBudget(max_input_tokens=20000, input_tokens=25000).check()
    assert "Input tokens count" in str(exc_info.value)


def test_evidence_assessor(monkeypatch):
    from app.services.v4.evidence_assessor import EvidenceAssessor
    from app.schemas.v4.rag import EvidenceAssessmentResult
    from app.schemas.search import SearchSource
    from app.models.file import FileModality
    from uuid import uuid4

    mock_run_result = MagicMock()
    mock_run_result.output = EvidenceAssessmentResult(
        is_sufficient=True,
        reasoning="All clear",
        missing_information=None,
    )
    monkeypatch.setattr(pydantic_ai.Agent, "run_sync", lambda self, prompt: mock_run_result)

    settings = Settings()
    assessor = EvidenceAssessor(settings)
    res = assessor.evaluate("test query", [SearchSource(
        segment_id=uuid4(),
        file_id=uuid4(),
        modality=FileModality.TEXT,
        title="test",
        content="source content",
        score=0.9,
        source_path="test_path",
    )])
    assert res.is_sufficient is True


def test_citation_verifier(monkeypatch):
    from app.services.v4.citation_verifier import CitationVerifier
    from app.schemas.v4.rag import CitationMapResult, CitationMapping
    from app.schemas.search import SearchSource
    from app.models.file import FileModality
    from uuid import uuid4

    mock_run_result = MagicMock()
    mock_run_result.output = CitationMapResult(
        has_valid_citations=True,
        mappings=[
            CitationMapping(
                citation_id="1",
                supports_claim=True,
                snippet_evidence="matching snippet",
            )
        ],
    )
    monkeypatch.setattr(pydantic_ai.Agent, "run_sync", lambda self, prompt: mock_run_result)

    settings = Settings()
    verifier = CitationVerifier(settings)
    res = verifier.verify("test query", "draft [1]", [SearchSource(
        segment_id=uuid4(),
        file_id=uuid4(),
        modality=FileModality.TEXT,
        title="test",
        content="matching snippet",
        score=0.9,
        source_path="test_path",
    )])
    assert res.has_valid_citations is True


def test_groundedness_evaluator(monkeypatch):
    from app.services.v4.groundedness_evaluator import GroundednessEvaluator
    from app.schemas.v4.rag import GroundednessResult
    from app.schemas.search import SearchSource
    from app.models.file import FileModality
    from uuid import uuid4

    mock_run_result = MagicMock()
    mock_run_result.output = GroundednessResult(
        score=0.95,
        reasoning="Good groundedness",
        is_grounded=True,
    )
    monkeypatch.setattr(pydantic_ai.Agent, "run_sync", lambda self, prompt: mock_run_result)

    settings = Settings()
    evaluator = GroundednessEvaluator(settings)
    res = evaluator.evaluate("test query", "grounded answer", [SearchSource(
        segment_id=uuid4(),
        file_id=uuid4(),
        modality=FileModality.TEXT,
        title="test",
        content="grounded answer source",
        score=0.9,
        source_path="test_path",
    )])
    assert res.score == 0.95
    assert res.is_grounded is True


def test_memory_manager_fallbacks(tmp_path):
    from app.services.v4.memory_manager import MemoryManager
    from uuid import uuid4

    settings = Settings()
    mgr = MemoryManager(settings)
    
    # Override paths to temporary path to avoid writing to app directory
    mgr.letta_fallback_path = str(tmp_path / "letta_fallback.json")
    mgr.graphiti_fallback_path = str(tmp_path / "graphiti_fallback.json")

    pid = uuid4()
    # Test Letta fallback
    assert mgr.get_user_memory(pid) == ""
    mgr.update_user_memory(pid, "We use Neon Postgres database.", "Acknowledged database choice.")
    assert "Neon Postgres" in mgr.get_user_memory(pid)

    # Test Graphiti fallback
    mgr.index_file(pid, "doc.txt", "We migrated to AWS RDS in June.")
    sources = mgr.query_temporal_graph(pid, "AWS RDS")
    assert len(sources) > 0
    assert "AWS RDS" in sources[0].content


