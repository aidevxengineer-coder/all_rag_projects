"""Pydantic request/response schemas."""
