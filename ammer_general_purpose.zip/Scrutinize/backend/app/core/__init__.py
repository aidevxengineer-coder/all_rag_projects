"""Core configuration and infrastructure helpers."""
