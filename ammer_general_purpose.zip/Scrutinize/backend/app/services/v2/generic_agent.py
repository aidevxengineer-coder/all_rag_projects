from dataclasses import dataclass
from typing import Iterator
from langsmith import traceable

from app.core.config import Settings
from app.services.v2.conversation_format import append_conversation_context
from app.services.v2.llm_clients import BaseLlmClient, LlmResponse
from app.services.v2.prompts import load_prompt


@dataclass(frozen=True)
class GenericReplyResult:
    answer: str
    llm_call: LlmResponse | None = None


class GenericAgent:
    """qwen3.5:0.8b — natural reply when the gate omits a generic reply."""

    def __init__(self, client: BaseLlmClient, settings: Settings) -> None:
        self._client = client
        self._model = settings.local_llm_gate_model
        self._system = load_prompt("generic_agent_system.txt")

    @traceable(name="GenericAgent.reply", run_type="chain")
    def reply(
        self,
        query: str,
        *,
        system_override: str | None = None,
        conversation_context: str = "",
    ) -> GenericReplyResult:
        user_lines = [query.strip()]
        append_conversation_context(user_lines, conversation_context)
        effective_system = system_override or self._system
        llm_response = self._client.generate(
            self._model,
            effective_system,
            "\n".join(user_lines),
        )
        return GenericReplyResult(
            answer=llm_response.content,
            llm_call=llm_response,
        )

    def reply_stream(
        self,
        query: str,
        *,
        system_override: str | None = None,
        conversation_context: str = "",
    ) -> Iterator[str]:
        user_lines = [query.strip()]
        append_conversation_context(user_lines, conversation_context)
        effective_system = system_override or self._system
        return self._client.generate_stream(
            self._model,
            effective_system,
            "\n".join(user_lines),
        )


