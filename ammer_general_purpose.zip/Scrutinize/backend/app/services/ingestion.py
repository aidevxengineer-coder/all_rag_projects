from dataclasses import dataclass
from uuid import UUID, uuid4

from app.models.file import File, FileModality
from app.services.embedding_service import EmbeddingService
from app.services.job_orchestrator import JobOrchestrator
from app.services.vector_store import VectorSegment, VectorStore

_NULL_UUID = UUID(int=0)  # Sentinel for files without a project_id (pre-multi-tenant legacy data)


@dataclass(frozen=True)
class TimedContent:
    content: str
    start_time: float | None = None
    end_time: float | None = None


def index_segments(
    orchestrator: JobOrchestrator,
    embedding_service: EmbeddingService,
    vector_store: VectorStore,
    file_record: File,
    segments: list[TimedContent],
    modality: FileModality,
) -> int:
    if not segments:
        raise ValueError("No segments to index")

    # Resolve the project_id for this file; fall back to null sentinel for legacy rows.
    project_id = file_record.project_id or _NULL_UUID

    from app.services.v5.untrusted import check_for_injection
    texts = [segment.content for segment in segments]
    vectors = embedding_service.embed_texts(texts)
    vector_segments: list[VectorSegment] = []

    for segment, vector in zip(segments, vectors, strict=True):
        segment_id = uuid4()
        is_poisoned = check_for_injection(segment.content)
        orchestrator.create_segment(
            file_id=file_record.id,
            modality=modality,
            content=segment.content,
            start_time=segment.start_time,
            end_time=segment.end_time,
            segment_id=segment_id,
            project_id=file_record.project_id,
            conversation_id=file_record.conversation_id,
            is_poisoned=is_poisoned,
        )
        vector_segments.append(
            VectorSegment(
                id=segment_id,
                vector=vector,
                file_id=file_record.id,
                project_id=project_id,
                conversation_id=str(file_record.conversation_id) if file_record.conversation_id else "",
                modality=modality.value,
                content=segment.content,
                source_path=file_record.storage_path,
                title=file_record.filename,
                start_time=segment.start_time,
                end_time=segment.end_time,
                is_poisoned=is_poisoned,
            )
        )

    vector_store.upsert_segments(vector_segments)

    # Index in Graphiti temporal graph (Phase 2)
    try:
        from app.core.config import get_settings
        from app.services.v4.memory_manager import MemoryManager
        settings = get_settings()
        memory_mgr = MemoryManager(settings)
        full_content = "\n".join(segment.content for segment in segments)
        if full_content.strip() and file_record.project_id:
            memory_mgr.index_file(
                project_id=file_record.project_id,
                filename=file_record.filename,
                content=full_content,
            )
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("Graphiti indexing failed during ingestion: %s", e)

    return len(vector_segments)

