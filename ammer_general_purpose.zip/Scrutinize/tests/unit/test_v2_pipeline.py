from unittest.mock import MagicMock
from uuid import uuid4

import pytest

from app.core.config import Settings
from app.models.file import FileModality
from app.schemas.search import SearchSource
from app.schemas.v2.search import ChatMessage, ConversationState
from app.services.v2.decision_agent import DecisionResult
from app.services.v2.pipeline_orchestrator import (
    LOW_CONFIDENCE_DISCLAIMER,
    NO_INDEXED_CONTENT,
    PipelineOrchestrator,
)
from app.services.v2.query_rewriter import RewrittenQuery
from app.services.v2.rag_gate import GateResult
from app.services.v2.generic_agent import GenericReplyResult
from app.services.v2.rag_synthesis_agent import SynthesisResult
from app.services.v2.retrieval_utils import RetrieveResult, RetrievalStats


def _settings(**overrides: object) -> Settings:
    defaults = {
        "local_llm_base_url": "http://llm.test",
        "v2_max_pipeline_attempts": 2,
        "v2_confidence_threshold": 0.7,
    }
    defaults.update(overrides)
    return Settings(**defaults)


def _retrieve_result(sources: list[SearchSource]) -> RetrieveResult:
    return RetrieveResult(sources=sources, stats=RetrievalStats.empty())


def _memory_mock() -> MagicMock:
    memory = MagicMock()
    memory.prepare.return_value = (ConversationState(), "")

    def _record(state: ConversationState, user: str, assistant: str) -> ConversationState:
        return ConversationState(
            messages=[
                *state.messages,
                ChatMessage(role="user", content=user),
                ChatMessage(role="assistant", content=assistant),
            ],
        )

    memory.record_exchange.side_effect = _record
    return memory


def _orchestrator(
    rewriter, gate, generic, rrf, synthesis, decision, memory, *, mcp_manager=None,
    **settings_overrides,
):
    return PipelineOrchestrator(
        rewriter,
        gate,
        generic,
        rrf,
        synthesis,
        decision,
        memory,
        _settings(**settings_overrides),
        mcp_manager=mcp_manager,
    )


@pytest.mark.unit
@pytest.mark.v2
def test_pipeline_gate_runs_before_rewrite():
    rewriter = MagicMock()
    gate = MagicMock()
    gate.classify.return_value = GateResult(
        route="generic",
        reason="Greeting",
        reply="Hello!",
    )
    generic = MagicMock()
    rrf = MagicMock()
    synthesis = MagicMock()
    decision = MagicMock()
    decision.evaluate.return_value = DecisionResult(
        verdict="good",
        confidence=0.95,
        feedback="",
        correct_route="generic",
    )
    memory = _memory_mock()

    orchestrator = _orchestrator(rewriter, gate, generic, rrf, synthesis, decision, memory)
    orchestrator.search("Hi there")

    gate.classify.assert_called_once()
    rewriter.rewrite.assert_not_called()
    _, gate_kwargs = gate.classify.call_args
    assert gate_kwargs.get("conversation_context") == ""


@pytest.mark.unit
@pytest.mark.v2
def test_pipeline_generic_uses_decision_confidence():
    rewriter = MagicMock()
    gate = MagicMock()
    gate.classify.return_value = GateResult(
        route="generic",
        reason="Chitchat",
        reply="Here is a joke.",
    )
    generic = MagicMock()
    rrf = MagicMock()
    synthesis = MagicMock()
    decision = MagicMock()
    decision.evaluate.return_value = DecisionResult(
        verdict="good",
        confidence=0.91,
        feedback="",
        correct_route="generic",
    )
    memory = _memory_mock()

    orchestrator = _orchestrator(rewriter, gate, generic, rrf, synthesis, decision, memory)
    response = orchestrator.search("Tell me a joke")

    assert response.route == "generic"
    assert response.answer == "Here is a joke."
    assert response.confidence == 0.91
    decision.evaluate.assert_called_once()
    generic.reply.assert_not_called()
    rrf.retrieve.assert_not_called()


@pytest.mark.unit
@pytest.mark.v2
def test_pipeline_generic_escalates_to_rag_when_decision_says_so():
    rewriter = MagicMock()
    rewriter.rewrite.return_value = RewrittenQuery(text="garlic amount pasta recipe")
    gate = MagicMock()
    gate.classify.return_value = GateResult(
        route="generic",
        reason="Misclassified",
        reply="Maybe two cloves?",
    )
    generic = MagicMock()
    rrf = MagicMock()
    source = SearchSource(
        segment_id=uuid4(),
        file_id=uuid4(),
        modality=FileModality.TEXT,
        title="pasta.md",
        content="Use 2 cloves garlic.",
        source_path="https://example.com/pasta.md",
        score=0.9,
    )
    rrf.retrieve.return_value = _retrieve_result([source])
    synthesis = MagicMock()
    synthesis.synthesize.return_value = SynthesisResult(answer="The recipe uses two cloves of garlic.")
    decision = MagicMock()
    decision.evaluate.side_effect = [
        DecisionResult(
            verdict="retry",
            confidence=0.2,
            feedback="Cooking question needs library search.",
            correct_route="rag",
        ),
        DecisionResult(verdict="good", confidence=0.88, feedback="", correct_route="rag"),
    ]
    memory = _memory_mock()

    orchestrator = _orchestrator(rewriter, gate, generic, rrf, synthesis, decision, memory)
    response = orchestrator.search("How much garlic in the pasta recipe?")

    assert response.route == "rag"
    assert response.answer == "The recipe uses two cloves of garlic."
    assert decision.evaluate.call_count == 2
    rrf.retrieve.assert_called_once()


@pytest.mark.unit
@pytest.mark.v2
def test_pipeline_generic_fallback_calls_generic_agent():
    rewriter = MagicMock()
    gate = MagicMock()
    gate.classify.return_value = GateResult(route="generic", reason="Chitchat", reply=None)
    generic = MagicMock()
    generic.reply.return_value = GenericReplyResult(answer="Sure, I can help with that.")
    rrf = MagicMock()
    synthesis = MagicMock()
    decision = MagicMock()
    decision.evaluate.return_value = DecisionResult(
        verdict="good",
        confidence=0.85,
        feedback="",
        correct_route="generic",
    )
    memory = _memory_mock()

    orchestrator = _orchestrator(rewriter, gate, generic, rrf, synthesis, decision, memory)
    response = orchestrator.search("What's the weather?")

    assert response.answer == "Sure, I can help with that."
    generic.reply.assert_called_once()
    decision.evaluate.assert_called_once()


@pytest.mark.unit
@pytest.mark.v2
def test_pipeline_orchestrator_rag_with_synthesis():
    rewriter = MagicMock()
    rewriter.rewrite.return_value = RewrittenQuery(text="garlic amount pasta recipe")
    gate = MagicMock()
    gate.classify.return_value = GateResult(route="rag", reason="Cooking query")
    generic = MagicMock()
    rrf = MagicMock()
    source = SearchSource(
        segment_id=uuid4(),
        file_id=uuid4(),
        modality=FileModality.TEXT,
        title="pasta.md",
        content="Use 2 cloves garlic.",
        source_path="https://example.com/pasta.md",
        score=0.9,
    )
    rrf.retrieve.return_value = _retrieve_result([source])
    synthesis = MagicMock()
    synthesis.synthesize.return_value = SynthesisResult(answer="The recipe uses two cloves of garlic.")
    decision = MagicMock()
    decision.evaluate.return_value = DecisionResult(
        verdict="good", confidence=0.88, feedback="", correct_route="rag"
    )
    memory = _memory_mock()

    orchestrator = _orchestrator(rewriter, gate, generic, rrf, synthesis, decision, memory)
    response = orchestrator.search("How much garlic in the pasta recipe?")

    assert response.route == "rag"
    assert response.answer == "The recipe uses two cloves of garlic."
    assert response.rewritten_query == "garlic amount pasta recipe"
    decision.evaluate.assert_called_once()
    rewriter.rewrite.assert_called_once()


@pytest.mark.unit
@pytest.mark.v2
def test_pipeline_pdf_intent_uses_rewritten_topic_and_calls_mcp_without_discovery():
    rewriter = MagicMock()
    rewriter.rewrite.return_value = RewrittenQuery(
        text="OpenAI news updates and announcements."
    )
    gate = MagicMock()
    gate.classify.return_value = GateResult(route="rag", reason="OpenAI news request", requested_tool="generate_pdf")
    generic = MagicMock()
    rrf = MagicMock()
    source = SearchSource(
        segment_id=uuid4(),
        file_id=uuid4(),
        modality=FileModality.TEXT,
        title="openai-news.txt",
        content="OpenAI announced new Academy courses.",
        source_path="https://example.com/openai-news",
        score=0.9,
    )
    rrf.retrieve.return_value = _retrieve_result([source])
    synthesis = MagicMock()
    synthesis.synthesize.return_value = SynthesisResult(
        answer="OpenAI announced new Academy courses."
    )
    decision = MagicMock()
    decision.evaluate.return_value = DecisionResult(
        verdict="good", confidence=0.95, feedback="", correct_route="rag"
    )
    memory = _memory_mock()
    mcp_manager = MagicMock()
    mcp_manager.is_enabled.return_value = True
    mcp_manager.list_tools.return_value = []
    mcp_manager.call_tool.return_value = (
        "C:/tmp/generated_pdfs/openai-news-updates.pdf"
    )

    orchestrator = _orchestrator(
        rewriter,
        gate,
        generic,
        rrf,
        synthesis,
        decision,
        memory,
        mcp_manager=mcp_manager,
    )
    response = orchestrator.search("generate me pdf on openai news")

    assert "OpenAI announced new Academy courses." in response.answer
    assert "/v2/pdf/download/" in response.answer
    assert "Download PDF" in response.answer
    assert synthesis.synthesize.call_args.args[0] == "OpenAI news updates and announcements."
    assert synthesis.synthesize.call_args.kwargs["tools"] is None
    mcp_manager.list_tools.assert_not_called()
    mcp_manager.call_tool.assert_called_once_with(
        "generate_pdf",
        {
            "title": "generate-me-pdf-on-openai-news",
            "content": "OpenAI announced new Academy courses.",
        },
    )


@pytest.mark.unit
@pytest.mark.v2
def test_streaming_pipeline_pdf_intent_calls_mcp_without_discovery():
    rewriter = MagicMock()
    rewriter.rewrite.return_value = RewrittenQuery(text="OpenAI news updates.")
    gate = MagicMock()
    gate.classify.return_value = GateResult(route="rag", reason="OpenAI news request", requested_tool="generate_pdf")
    generic = MagicMock()
    rrf = MagicMock()
    source = SearchSource(
        segment_id=uuid4(),
        file_id=uuid4(),
        modality=FileModality.TEXT,
        title="openai-news.txt",
        content="OpenAI announced new Academy courses.",
        source_path="https://example.com/openai-news",
        score=0.9,
    )
    rrf.retrieve.return_value = _retrieve_result([source])
    synthesis = MagicMock()
    synthesis.synthesize.return_value = SynthesisResult(
        answer="OpenAI announced new Academy courses."
    )
    decision = MagicMock()
    decision.evaluate.return_value = DecisionResult(
        verdict="good", confidence=0.95, feedback="", correct_route="rag"
    )
    memory = _memory_mock()
    mcp_manager = MagicMock()
    mcp_manager.is_enabled.return_value = True
    mcp_manager.list_tools.return_value = []
    mcp_manager.call_tool.return_value = "C:/tmp/generated_pdfs/openai-news.pdf"

    orchestrator = _orchestrator(
        rewriter,
        gate,
        generic,
        rrf,
        synthesis,
        decision,
        memory,
        mcp_manager=mcp_manager,
    )
    events = "".join(
        orchestrator.search_stream("generate me pdf on openai news")
    )

    assert '"step": "tool_call"' in events
    assert '"step": "tool_call_end"' in events
    assert "openai-news.pdf" in events
    assert synthesis.synthesize.call_args.args[0] == "OpenAI news updates."
    mcp_manager.list_tools.assert_not_called()
    mcp_manager.call_tool.assert_called_once()


@pytest.mark.unit
@pytest.mark.v2
def test_pipeline_orchestrator_rag_empty_results():
    rewriter = MagicMock()
    rewriter.rewrite.return_value = RewrittenQuery(text="missing topic")
    gate = MagicMock()
    gate.classify.return_value = GateResult(route="rag", reason="Library query")
    generic = MagicMock()
    rrf = MagicMock()
    rrf.retrieve.return_value = _retrieve_result([])
    synthesis = MagicMock()
    decision = MagicMock()
    decision.evaluate.return_value = DecisionResult(
        verdict="good", confidence=0.75, feedback="", correct_route="rag"
    )
    memory = _memory_mock()

    orchestrator = _orchestrator(rewriter, gate, generic, rrf, synthesis, decision, memory)
    response = orchestrator.search("What does the doc say about unicorns?")

    assert response.answer == NO_INDEXED_CONTENT
    synthesis.synthesize.assert_not_called()


@pytest.mark.unit
@pytest.mark.v2
def test_pipeline_orchestrator_retries_then_succeeds():
    rewriter = MagicMock()
    rewriter.rewrite.side_effect = [
        RewrittenQuery(text="vague garlic query"),
        RewrittenQuery(text="garlic cloves pasta recipe quantity"),
    ]
    gate = MagicMock()
    gate.classify.return_value = GateResult(route="rag", reason="Library query")
    generic = MagicMock()
    rrf = MagicMock()
    rrf.retrieve.return_value = _retrieve_result([])
    synthesis = MagicMock()
    decision = MagicMock()
    decision.evaluate.side_effect = [
        DecisionResult(
            verdict="retry", confidence=0.4, feedback="Add recipe keywords.", correct_route="rag"
        ),
        DecisionResult(verdict="good", confidence=0.85, feedback="", correct_route="rag"),
    ]
    memory = _memory_mock()

    orchestrator = _orchestrator(rewriter, gate, generic, rrf, synthesis, decision, memory)
    response = orchestrator.search("garlic?")

    assert response.attempts == 2
    assert response.confidence == 0.85


@pytest.mark.unit
@pytest.mark.v2
def test_pipeline_orchestrator_fallback_disclaimer_after_max_attempts():
    rewriter = MagicMock()
    rewriter.rewrite.side_effect = [
        RewrittenQuery(text="weak query"),
        RewrittenQuery(text="weak query revised"),
    ]
    gate = MagicMock()
    gate.classify.return_value = GateResult(route="rag", reason="Library query")
    generic = MagicMock()
    rrf = MagicMock()
    rrf.retrieve.return_value = _retrieve_result([])
    synthesis = MagicMock()
    decision = MagicMock()
    decision.evaluate.return_value = DecisionResult(
        verdict="retry", confidence=0.2, feedback="Too vague.", correct_route="rag"
    )
    memory = _memory_mock()

    orchestrator = _orchestrator(rewriter, gate, generic, rrf, synthesis, decision, memory)
    response = orchestrator.search("something obscure")

    assert response.disclaimer_appended is True
    assert LOW_CONFIDENCE_DISCLAIMER in response.answer
